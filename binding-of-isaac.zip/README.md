<h1>The Binding of Isaac</h1>

This repo is for the final project of the Algorithms Course from UFRGS, an university from brazil.
We made all the game using tha basic concepts of programing with the C lang and using "raylib", a library that helps to create the game's graphical interface and others funcionalities.
